import React from 'react';
import ReactDOM from 'react-dom';

const App = React.createClass({
  render: function () {
    return (<h1>Test Component</h1>);
  }
});

const mountNode = document.querySelector('#root');

ReactDOM.render(<App />, mountNode);
