import React from 'react';

export const About = (props) => (
  <div>
    The about page
  </div>
)

export default About;
